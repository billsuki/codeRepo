package cn.xlink.admin.myscaleview;

/**
 * Created by admin on 2016/8/24.
 */
public class DayBean {

    private long startNum ;
    private long endNum ;
    private int type ;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getStartNum() {
        return startNum;
    }

    public void setStartNum(long startNum) {
        this.startNum = startNum;
    }

    public long getEndNum() {
        return endNum;
    }

    public void setEndNum(long endNum) {
        this.endNum = endNum;
    }
}
